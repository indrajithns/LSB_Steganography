Command Line Argument To Execute The C Programming Project01 For LSB Image Steganography

Command to run all the .c files: gcc *.c    
For Encoding: ./a.out -e beautiful.bmp secret.txt stego.bmp
For Decoding: ./a.out -d stego.bmp decode.txt

This will give the required output
